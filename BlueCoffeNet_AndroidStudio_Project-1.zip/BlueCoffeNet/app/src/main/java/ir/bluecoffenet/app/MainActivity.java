package ir.bluecoffenet.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {

    private static final String HOME = "https://bluecoffenet.ir";
    private static final String HOST = "bluecoffenet.ir";

    private WebView web;
    private SwipeRefreshLayout refresh;
    private ProgressBar progress;
    private LinearLayout errorView;
    private ValueCallback<Uri[]> filePathCallback;

    private final androidx.activity.result.ActivityResultLauncher<Intent> fileLauncher =
        registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(), r -> {
            Uri[] result = null;
            if (r.getResultCode() == RESULT_OK && r.getData() != null) {
                result = WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData());
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        });

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        web = findViewById(R.id.webview);
        refresh = findViewById(R.id.refresh);
        progress = findViewById(R.id.progress);
        errorView = findViewById(R.id.error_view);
        Button retry = findViewById(R.id.retry);
        retry.setOnClickListener(v -> { errorView.setVisibility(View.GONE); web.setVisibility(View.VISIBLE); web.reload(); });

        refresh.setColorSchemeResources(R.color.brand_blue);
        refresh.setOnRefreshListener(() -> web.reload());

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        s.setCacheMode(isOnline() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager_enqueue(url, ua, cd, mime);
            } catch (Exception e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                String host = u.getHost() == null ? "" : u.getHost();
                if (scheme.equals("http") || scheme.equals("https")) {
                    if (host.equals(HOST) || host.endsWith("." + HOST)) return false;
                    openExternal(u);
                    return true;
                }
                openExternal(u); // tel:, mailto:, intent:, etc.
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView v, String url) {
                progress.setVisibility(View.GONE);
                refresh.setRefreshing(false);
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    web.setVisibility(View.GONE);
                    errorView.setVisibility(View.VISIBLE);
                    refresh.setRefreshing(false);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { progress.setProgress(p); }
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try { fileLauncher.launch(p.createIntent()); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (web.canGoBack()) web.goBack();
                else { setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); }
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else {
            Uri data = getIntent().getData();
            web.loadUrl(data != null ? data.toString() : HOME);
        }
    }

    private void DownloadManager_enqueue(String url, String ua, String cd, String mime) {
        android.app.DownloadManager.Request r = new android.app.DownloadManager.Request(Uri.parse(url));
        r.setMimeType(mime);
        r.addRequestHeader("User-Agent", ua);
        String c = CookieManager.getInstance().getCookie(url);
        if (c != null) r.addRequestHeader("Cookie", c);
        r.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        r.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime));
        ((android.app.DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
    }

    private void openExternal(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        Network n = cm.getActiveNetwork();
        if (n == null) return false;
        NetworkCapabilities c = cm.getNetworkCapabilities(n);
        return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
    @Override protected void onPause() { super.onPause(); web.onPause(); CookieManager.getInstance().flush(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
}
